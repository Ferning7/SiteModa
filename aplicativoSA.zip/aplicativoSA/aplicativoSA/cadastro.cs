﻿using LOGINv4;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplicativoSA
{
    public partial class cadastro : Form
    {

        public static Dictionary<string, string> contas = new Dictionary<string, string>();

        public void Cadastrar(string email, string senha)
        {

            email = inputEmailCadastro.Text;

            senha = inputSenhaCadastro.Text;

            contas.Add(email, senha);

        }

        public cadastro()
        {
            InitializeComponent();
        }

        private void inputEmailCadastro_TextChanged(object sender, EventArgs e)
        {



        }

        private void inputSenhaCadastro_TextChanged(object sender, EventArgs e)
        {

        }

       

       

        private void cadastrarButton_Click(object sender, EventArgs e)
        {

            try
            {

                if (inputSenhaCadastro.Text.Count() >= 8)
                {

                    Cadastrar(inputEmailCadastro.Text, inputSenhaCadastro.Text);

                    login login = new login();

                    login.Show();

                    this.Visible = false;

                }
                else
                {
                    MessageBox.Show(
                        "A senha deve ter pelo menos 8 caracteres!",
                        "Atenção",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }

            }
            catch (Exception ex)
            {

            }

        }
    }
}
