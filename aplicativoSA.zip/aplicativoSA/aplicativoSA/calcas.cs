namespace aplicativoSA;

public partial class calcas : Form
{
    public calcas()
    {
        InitializeComponent();
    }
}