namespace aplicativoSA;

public partial class camisas : Form
{
    public camisas()
    {
        InitializeComponent();
    }
}