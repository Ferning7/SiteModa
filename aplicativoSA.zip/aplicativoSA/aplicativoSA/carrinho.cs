namespace aplicativoSA;

public partial class carrinho : Form
{
    public carrinho()
    {
        InitializeComponent();
    }
}