namespace aplicativoSA;

public partial class formContent : Form
{
    public formContent()
    {
        InitializeComponent();
    }
}