﻿namespace aplicativoSA
{
    partial class home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            panel1 = new System.Windows.Forms.Panel();
            pictureBox8 = new System.Windows.Forms.PictureBox();
            txtBoxBusca = new System.Windows.Forms.TextBox();
            pictureBox7 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            panel2 = new System.Windows.Forms.Panel();
            linkLabel1 = new System.Windows.Forms.LinkLabel();
            linkCamisas = new System.Windows.Forms.LinkLabel();
            linkCalcas = new System.Windows.Forms.LinkLabel();
            linkMulher = new System.Windows.Forms.LinkLabel();
            linkHomem = new System.Windows.Forms.LinkLabel();
            content = new System.Windows.Forms.Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(txtBoxBusca);
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox3);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(978, 61);
            panel1.TabIndex = 0;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = ((System.Drawing.Image)resources.GetObject("pictureBox8.Image"));
            pictureBox8.Location = new System.Drawing.Point(904, 13);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new System.Drawing.Size(34, 35);
            pictureBox8.TabIndex = 12;
            pictureBox8.TabStop = false;
            pictureBox8.Tag = "";
            pictureBox8.Click += pictureBox8_Click;
            // 
            // txtBoxBusca
            // 
            txtBoxBusca.Location = new System.Drawing.Point(399, 19);
            txtBoxBusca.Name = "txtBoxBusca";
            txtBoxBusca.PlaceholderText = "BUSCA";
            txtBoxBusca.Size = new System.Drawing.Size(197, 27);
            txtBoxBusca.TabIndex = 11;
            // 
            // pictureBox7
            // 
            pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            pictureBox7.Image = ((System.Drawing.Image)resources.GetObject("pictureBox7.Image"));
            pictureBox7.Location = new System.Drawing.Point(602, 16);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new System.Drawing.Size(30, 35);
            pictureBox7.TabIndex = 10;
            pictureBox7.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new System.Drawing.Point(5, -69);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(204, 197);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 9;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // panel2
            // 
            panel2.BackColor = System.Drawing.Color.FromArgb(((int)((byte)221)), ((int)((byte)222)), ((int)((byte)203)));
            panel2.Controls.Add(linkLabel1);
            panel2.Controls.Add(linkCamisas);
            panel2.Controls.Add(linkCalcas);
            panel2.Controls.Add(linkMulher);
            panel2.Controls.Add(linkHomem);
            panel2.Dock = System.Windows.Forms.DockStyle.Left;
            panel2.Location = new System.Drawing.Point(0, 61);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(211, 463);
            panel2.TabIndex = 1;
            // 
            // linkLabel1
            // 
            linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            linkLabel1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)0));
            linkLabel1.LinkColor = System.Drawing.Color.Black;
            linkLabel1.Location = new System.Drawing.Point(41, 49);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new System.Drawing.Size(122, 31);
            linkLabel1.TabIndex = 19;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "HOME";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked_1;
            // 
            // linkCamisas
            // 
            linkCamisas.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            linkCamisas.Cursor = System.Windows.Forms.Cursors.Hand;
            linkCamisas.Font = new System.Drawing.Font("Palatino Linotype", 14.25F);
            linkCamisas.LinkColor = System.Drawing.Color.Black;
            linkCamisas.Location = new System.Drawing.Point(41, 155);
            linkCamisas.Name = "linkCamisas";
            linkCamisas.Size = new System.Drawing.Size(122, 37);
            linkCamisas.TabIndex = 18;
            linkCamisas.TabStop = true;
            linkCamisas.Text = "CAMISAS";
            linkCamisas.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkCalcas
            // 
            linkCalcas.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            linkCalcas.Cursor = System.Windows.Forms.Cursors.Hand;
            linkCalcas.Font = new System.Drawing.Font("Palatino Linotype", 14.25F);
            linkCalcas.LinkColor = System.Drawing.Color.Black;
            linkCalcas.Location = new System.Drawing.Point(41, 103);
            linkCalcas.Name = "linkCalcas";
            linkCalcas.Size = new System.Drawing.Size(122, 35);
            linkCalcas.TabIndex = 14;
            linkCalcas.TabStop = true;
            linkCalcas.Text = "CALÇAS";
            linkCalcas.LinkClicked += linkLabel3_LinkClicked;
            // 
            // linkMulher
            // 
            linkMulher.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            linkMulher.Cursor = System.Windows.Forms.Cursors.Hand;
            linkMulher.Font = new System.Drawing.Font("Palatino Linotype", 14.25F);
            linkMulher.LinkColor = System.Drawing.Color.Black;
            linkMulher.Location = new System.Drawing.Point(41, 264);
            linkMulher.Name = "linkMulher";
            linkMulher.Size = new System.Drawing.Size(122, 37);
            linkMulher.TabIndex = 13;
            linkMulher.TabStop = true;
            linkMulher.Text = "MULHER";
            linkMulher.LinkClicked += linkLabel2_LinkClicked;
            // 
            // linkHomem
            // 
            linkHomem.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
            linkHomem.Cursor = System.Windows.Forms.Cursors.Hand;
            linkHomem.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)0));
            linkHomem.LinkColor = System.Drawing.Color.Black;
            linkHomem.Location = new System.Drawing.Point(41, 207);
            linkHomem.Name = "linkHomem";
            linkHomem.Size = new System.Drawing.Size(122, 31);
            linkHomem.TabIndex = 12;
            linkHomem.TabStop = true;
            linkHomem.Text = "HOMEM";
            linkHomem.LinkClicked += linkHomem_LinkClicked;
            // 
            // content
            // 
            content.Dock = System.Windows.Forms.DockStyle.Fill;
            content.Location = new System.Drawing.Point(211, 61);
            content.Name = "content";
            content.Size = new System.Drawing.Size(767, 463);
            content.TabIndex = 2;
            // 
            // home
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(978, 524);
            Controls.Add(content);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        private System.Windows.Forms.LinkLabel linkLabel1;

        #endregion

        private Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel linkCalcas;
        private System.Windows.Forms.LinkLabel linkMulher;
        private System.Windows.Forms.LinkLabel linkHomem;
        private PictureBox pictureBox3;
        private PictureBox pictureBox8;
        private TextBox txtBoxBusca;
        private PictureBox pictureBox7;
        private System.Windows.Forms.LinkLabel linkCamisas;
        private Panel content;
    }
}
