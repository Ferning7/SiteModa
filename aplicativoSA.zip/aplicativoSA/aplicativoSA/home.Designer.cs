﻿namespace aplicativoSA;

partial class home
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
        panel1 = new System.Windows.Forms.Panel();
        txtBoxBusca = new System.Windows.Forms.TextBox();
        pictureBox3 = new System.Windows.Forms.PictureBox();
        pictureBox2 = new System.Windows.Forms.PictureBox();
        pictureBox1 = new System.Windows.Forms.PictureBox();
        pnlNav = new System.Windows.Forms.Panel();
        linkLabel3 = new System.Windows.Forms.LinkLabel();
        linkLabel2 = new System.Windows.Forms.LinkLabel();
        linkLabel1 = new System.Windows.Forms.LinkLabel();
        pictureBox4 = new System.Windows.Forms.PictureBox();
        linkMulher = new System.Windows.Forms.LinkLabel();
        pictureBox6 = new System.Windows.Forms.PictureBox();
        linkHomem = new System.Windows.Forms.LinkLabel();
        pictureBox5 = new System.Windows.Forms.PictureBox();
        content = new System.Windows.Forms.Panel();
        panel1.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
        pnlNav.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
        SuspendLayout();
        // 
        // panel1
        // 
        panel1.BackColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        panel1.Controls.Add(txtBoxBusca);
        panel1.Controls.Add(pictureBox3);
        panel1.Controls.Add(pictureBox2);
        panel1.Controls.Add(pictureBox1);
        panel1.Dock = System.Windows.Forms.DockStyle.Top;
        panel1.Location = new System.Drawing.Point(0, 0);
        panel1.Name = "panel1";
        panel1.Size = new System.Drawing.Size(996, 59);
        panel1.TabIndex = 0;
        panel1.Visible = false;
        panel1.Paint += panel1_Paint;
        // 
        // txtBoxBusca
        // 
        txtBoxBusca.Location = new System.Drawing.Point(417, 16);
        txtBoxBusca.Name = "txtBoxBusca";
        txtBoxBusca.PlaceholderText = "BUSCA";
        txtBoxBusca.Size = new System.Drawing.Size(197, 23);
        txtBoxBusca.TabIndex = 3;
        txtBoxBusca.TextChanged += textBox1_TextChanged;
        // 
        // pictureBox3
        // 
        pictureBox3.Image = ((System.Drawing.Image)resources.GetObject("pictureBox3.Image"));
        pictureBox3.Location = new System.Drawing.Point(0, -74);
        pictureBox3.Name = "pictureBox3";
        pictureBox3.Size = new System.Drawing.Size(204, 207);
        pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox3.TabIndex = 2;
        pictureBox3.TabStop = false;
        pictureBox3.Click += pictureBox3_Click;
        // 
        // pictureBox2
        // 
        pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
        pictureBox2.Image = ((System.Drawing.Image)resources.GetObject("pictureBox2.Image"));
        pictureBox2.Location = new System.Drawing.Point(620, 13);
        pictureBox2.Name = "pictureBox2";
        pictureBox2.Size = new System.Drawing.Size(30, 35);
        pictureBox2.TabIndex = 2;
        pictureBox2.TabStop = false;
        pictureBox2.Click += pictureBox2_Click;
        // 
        // pictureBox1
        // 
        pictureBox1.Image = ((System.Drawing.Image)resources.GetObject("pictureBox1.Image"));
        pictureBox1.Location = new System.Drawing.Point(905, 13);
        pictureBox1.Name = "pictureBox1";
        pictureBox1.Size = new System.Drawing.Size(34, 35);
        pictureBox1.TabIndex = 2;
        pictureBox1.TabStop = false;
        pictureBox1.Tag = "";
        pictureBox1.Click += pictureBox1_Click;
        // 
        // pnlNav
        // 
        pnlNav.BackColor = System.Drawing.Color.FromArgb(((int)((byte)221)), ((int)((byte)223)), ((int)((byte)203)));
        pnlNav.Controls.Add(linkLabel3);
        pnlNav.Controls.Add(linkLabel2);
        pnlNav.Controls.Add(linkLabel1);
        pnlNav.Controls.Add(pictureBox4);
        pnlNav.Controls.Add(linkMulher);
        pnlNav.Controls.Add(pictureBox6);
        pnlNav.Controls.Add(linkHomem);
        pnlNav.Controls.Add(pictureBox5);
        pnlNav.Dock = System.Windows.Forms.DockStyle.Left;
        pnlNav.Location = new System.Drawing.Point(0, 59);
        pnlNav.Name = "pnlNav";
        pnlNav.Size = new System.Drawing.Size(175, 509);
        pnlNav.TabIndex = 1;
        pnlNav.Visible = false;
        pnlNav.Paint += panel2_Paint;
        // 
        // linkLabel3
        // 
        linkLabel3.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
        linkLabel3.Font = new System.Drawing.Font("Palatino Linotype", 14.25F);
        linkLabel3.LinkColor = System.Drawing.Color.Black;
        linkLabel3.Location = new System.Drawing.Point(55, 205);
        linkLabel3.Name = "linkLabel3";
        linkLabel3.Size = new System.Drawing.Size(115, 22);
        linkLabel3.TabIndex = 11;
        linkLabel3.TabStop = true;
        linkLabel3.Text = "CALÇAS";
        linkLabel3.LinkClicked += linkLabel3_LinkClicked_1;
        // 
        // linkLabel2
        // 
        linkLabel2.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
        linkLabel2.Font = new System.Drawing.Font("Palatino Linotype", 14.25F);
        linkLabel2.LinkColor = System.Drawing.Color.Black;
        linkLabel2.Location = new System.Drawing.Point(55, 142);
        linkLabel2.Name = "linkLabel2";
        linkLabel2.Size = new System.Drawing.Size(115, 22);
        linkLabel2.TabIndex = 10;
        linkLabel2.TabStop = true;
        linkLabel2.Text = "MULHER";
        linkLabel2.LinkClicked += linkLabel2_LinkClicked_2;
        // 
        // linkLabel1
        // 
        linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
        linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
        linkLabel1.LinkColor = System.Drawing.Color.White;
        linkLabel1.Location = new System.Drawing.Point(49, 202);
        linkLabel1.Name = "linkLabel1";
        linkLabel1.Size = new System.Drawing.Size(97, 22);
        linkLabel1.TabIndex = 9;
        linkLabel1.LinkClicked += linkLabel1_LinkClicked;
        // 
        // pictureBox4
        // 
        pictureBox4.Image = ((System.Drawing.Image)resources.GetObject("pictureBox4.Image"));
        pictureBox4.Location = new System.Drawing.Point(9, 197);
        pictureBox4.Name = "pictureBox4";
        pictureBox4.Size = new System.Drawing.Size(39, 37);
        pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox4.TabIndex = 8;
        pictureBox4.TabStop = false;
        pictureBox4.Click += pictureBox4_Click;
        // 
        // linkMulher
        // 
        linkMulher.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        linkMulher.Cursor = System.Windows.Forms.Cursors.Hand;
        linkMulher.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
        linkMulher.LinkColor = System.Drawing.Color.White;
        linkMulher.Location = new System.Drawing.Point(48, 138);
        linkMulher.Name = "linkMulher";
        linkMulher.Size = new System.Drawing.Size(97, 22);
        linkMulher.TabIndex = 7;
        linkMulher.LinkClicked += linkLabel3_LinkClicked;
        // 
        // pictureBox6
        // 
        pictureBox6.Image = ((System.Drawing.Image)resources.GetObject("pictureBox6.Image"));
        pictureBox6.Location = new System.Drawing.Point(4, 128);
        pictureBox6.Name = "pictureBox6";
        pictureBox6.Size = new System.Drawing.Size(49, 51);
        pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox6.TabIndex = 6;
        pictureBox6.TabStop = false;
        pictureBox6.Click += pictureBox6_Click;
        // 
        // linkHomem
        // 
        linkHomem.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)((byte)123)), ((int)((byte)126)), ((int)((byte)91)));
        linkHomem.Cursor = System.Windows.Forms.Cursors.Hand;
        linkHomem.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)0));
        linkHomem.LinkColor = System.Drawing.Color.Black;
        linkHomem.Location = new System.Drawing.Point(56, 80);
        linkHomem.Name = "linkHomem";
        linkHomem.Size = new System.Drawing.Size(115, 22);
        linkHomem.TabIndex = 5;
        linkHomem.TabStop = true;
        linkHomem.Text = "HOMEM";
        linkHomem.LinkClicked += linkLabel2_LinkClicked;
        // 
        // pictureBox5
        // 
        pictureBox5.Image = ((System.Drawing.Image)resources.GetObject("pictureBox5.Image"));
        pictureBox5.Location = new System.Drawing.Point(8, 62);
        pictureBox5.Name = "pictureBox5";
        pictureBox5.Size = new System.Drawing.Size(44, 60);
        pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox5.TabIndex = 4;
        pictureBox5.TabStop = false;
        pictureBox5.Click += pictureBox5_Click;
        // 
        // content
        // 
        content.Dock = System.Windows.Forms.DockStyle.Fill;
        content.Location = new System.Drawing.Point(175, 59);
        content.Name = "content";
        content.Size = new System.Drawing.Size(821, 509);
        content.TabIndex = 2;
        content.Visible = false;
        content.Paint += content_Paint;
        // 
        // home
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        BackColor = System.Drawing.SystemColors.Control;
        ClientSize = new System.Drawing.Size(996, 568);
        Controls.Add(content);
        Controls.Add(pnlNav);
        Controls.Add(panel1);
        Location = new System.Drawing.Point(15, 15);
        Load += home_Load;
        panel1.ResumeLayout(false);
        panel1.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
        pnlNav.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
        ResumeLayout(false);
    }

    private System.Windows.Forms.LinkLabel linkLabel3;

    private System.Windows.Forms.LinkLabel linkLabel2;

    private System.Windows.Forms.Panel content;

    private System.Windows.Forms.LinkLabel linkLabel1;
    private System.Windows.Forms.PictureBox pictureBox4;

    private System.Windows.Forms.TextBox txtBoxBusca;

    private System.Windows.Forms.LinkLabel linkHomem;
    private System.Windows.Forms.PictureBox pictureBox5;
    private System.Windows.Forms.LinkLabel linkMulher;
    private System.Windows.Forms.PictureBox pictureBox6;

    private System.Windows.Forms.PictureBox pictureBox3;

    private System.Windows.Forms.PictureBox pictureBox2;

    private System.Windows.Forms.PictureBox pictureBox1;

    private System.Windows.Forms.Panel pnlNav;

    private System.Windows.Forms.Panel panel1;

    #endregion
}