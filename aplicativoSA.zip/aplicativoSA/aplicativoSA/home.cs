namespace aplicativoSA
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            
            
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            nav(new calcas(), content);

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            nav(new camisas(), content);

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            nav(new mulher(),content);

        }

        private void linkHomem_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            nav(new homem(), content);
            
        }

        public void nav(Form form, Panel panel)
        {
            
            form.TopLevel = false;
            panel.Controls.Clear();
            panel.Controls.Add(form);
            form.Show();


        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {



        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }
    }
}
