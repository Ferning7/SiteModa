namespace aplicativoSA;

public partial class home : Form
{
    public home()
    {
        InitializeComponent();
    }
    
    private void home_Load(object sender, EventArgs e)
    {
        
        
        
    }
    

    private void pictureBox6_Click(object sender, EventArgs e)
    {
      
    }

  

    private void panel2_Paint(object sender, PaintEventArgs e)
    {
      
    }

    private void pictureBox1_Click(object sender, EventArgs e)
    {
        
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
       
    }
    
    private void panel1_Paint(object sender, PaintEventArgs e)
    {
       
    }

    private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
     
        

    }

    private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
       
       
        
    }

    private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
        
       
        
    }

    private void pictureBox4_Click(object sender, EventArgs e)
    {
       
    }

    private void pictureBox3_Click(object sender, EventArgs e)
    {
       
    }
    
    private void pictureBox2_Click(object sender, EventArgs e)
    {
       
    }
    
    private void pictureBox5_Click(object sender, EventArgs e)
    {
       
    }
    
    private void content_Paint(object sender, PaintEventArgs e)
    {
        
    }

    private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
    {
        
    }

    private void linkLabel2_LinkClicked_2(object sender, LinkLabelLinkClickedEventArgs e)
    {
        
    }

    private void linkLabel3_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
    {
        
    }
    
}