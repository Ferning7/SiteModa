namespace aplicativoSA;

public partial class homem : Form
{
    public homem()
    {
        InitializeComponent();
    }
}