using aplicativoSA;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace LOGINv4
{
    public partial class login : Form
    {

        
        public void logar(string email, string senha)
        {


            try
            {

                if (senha.Count() >= 8)
                {


                    foreach (string i in cadastro.contas.Values)
                    {

                        if (inputEmail.Equals(cadastro.contas.Values) && inputSenha.Equals(cadastro.contas.Values))
                        {

                            home home = new home();
                            home.Show();
                            this.Visible = false;

                        }
                        else{

                            MessageBox.Show(
                                "Esse usu�rio n�o existe ou a senha est� incorreta!",
                                "Desculpe",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );

                        }

                    }

                }
               

            } catch(Exception ex)
            {

            }
            

        }

        public login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            try
            {

                cadastro cadastro = new cadastro();

                cadastro.Show();

                this.Visible = false;

                

            } catch(Exception ex)
            {

            }

        }

        private void LogInButton_Click(object sender, EventArgs e)
        {

            
          
            try
            {
                

                logar(inputEmail.Text, inputSenha.Text);

                  

                
                
            }
            catch(Exception ex)
            {

            }
            
            



        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
