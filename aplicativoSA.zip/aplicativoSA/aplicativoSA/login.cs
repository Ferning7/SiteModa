using aplicativoSA;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace LOGINv4
{
    public partial class login : Form
    {

        
        
        
        public void logar(string email, string senha)
        {
            try
            {
                if (email == "admin" && senha == "admin")
                {
                    home home = new home();
                    home.Show();
                    this.Hide();
                }
                
                // Verifica se a senha tem pelo menos 8 caracteres
                if (senha.Length >= 8)
                {
                    // Verifica se o email existe no dicionário
                    if (cadastro.contas.ContainsKey(email))
                    {
                        // Verifica se a senha é correta para o email
                        if (cadastro.contas[email] == senha)
                        {
                            // Login bem-sucedido, abrir a tela inicial
                            home home = new home();
                            home.Show();
                            this.Visible = false;
                        }
                        else
                        {
                            // Senha incorreta
                            MessageBox.Show(
                                "Senha incorreta!",
                                "Erro",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );
                        }
                    }
                    else
                    {
                        // Email não encontrado
                        MessageBox.Show(
                            "Esse usuário não existe!",
                            "Erro",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
                else
                {
                    MessageBox.Show(
                        "Esse usuário não existe ou a senha está incorreta!",
                        "Erro",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ocorreu um erro ao tentar realizar o login: " + ex.Message,
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }


        public login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            try
            {

                cadastro cadastro = new cadastro();

                cadastro.Show();

                this.Visible = false;

                

            } catch(Exception ex)
            {

            }

        }

        private void LogInButton_Click(object sender, EventArgs e)
        {

            
          
            try
            {
                

                logar(inputEmail.Text, inputSenha.Text);

                  

                
                
            }
            catch(Exception ex)
            {

            }
            
            



        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
