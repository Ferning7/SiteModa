namespace aplicativoSA;

public partial class mulher : Form
{
    public mulher()
    {
        InitializeComponent();
    }
}